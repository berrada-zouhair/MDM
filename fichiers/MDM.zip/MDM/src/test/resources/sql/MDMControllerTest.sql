delete from DEVICE;

insert into DEVICE (imei, ip, latitude, longitude, connected, INSTALLED_APPS, register_token) values ('imei1', 'IP1', '10.0', '10.0', TRUE, 'JSON', '55e4d6268c0be3913694bc');

insert into DEVICE (imei, ip, latitude, longitude, connected, INSTALLED_APPS, register_token) values ('imei2', 'IP2', '10.0', '10.0', FALSE, 'JSON', '55e4d6268c0be3913694bc');

insert into DEVICE (imei, ip, latitude, longitude, connected, INSTALLED_APPS, register_token) values ('imei3', 'IP3', '10.0', '10.0', FALSE, 'JSON', '55e4d6268c0be3913694bc');

insert into DEVICE (imei, ip, latitude, longitude, connected, INSTALLED_APPS, register_token) values ('imei4', 'IP4', '10.0', '10.0', TRUE, 'JSON', '55e4d6268c0be3913694bc');